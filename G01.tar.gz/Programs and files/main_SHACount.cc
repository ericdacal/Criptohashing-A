#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "couting_Bloom.h"
#include "keyGenerator.h"
#include "sha256.h"
#include <set>
using namespace std;




int main ()  {
  srand(time(NULL));             
  cout << "TamanyFiltre" << "\t" << "NumHash" << "\t" << "TamanyClau" << "\t" << "porcentatge" << "\t" << "FalsosPositius" << "\t" << "FalsosNegatius" << endl;
  for (int i = 500; i <= 10000; i += 50) {
    for (int j = 1;j <= 25;++j) {
      for (int k = 2;k <= 10;++k) {
       
        couting_Bloom filter(i,j);
        string key;
        string fileName = "claus";
        set <string> claus;
        fileName.append(to_string(k)).append(".txt");
        ifstream addFile(fileName);
        while (getline(addFile,key)) {
            filter.insert(sha256(key));
            claus.insert(key);
        }
        for (int l = 0;l < 4;++l) {
           int perc = l*33;
           int contFalse = 0;
           int contTrue = 0;
           fileName = "tests";
           fileName.append(to_string(k)).append(to_string(perc)).append(".txt");
           ifstream queryFile(fileName);
           int count = 0;
           while (getline(queryFile,key)) {
             if(count < (claus.size() * (l*33))) 
             {
                 filter.remove(sha256(key));
                 ++count;
             }
             bool member = filter.contains(sha256(key));
             if (member and claus.find(key) == claus.end()) ++contFalse;
             else if (claus.find(key) != claus.end())       ++contTrue;
           }
           cout << i << "\t" << j << "\t" << k << "\t" << perc << "\t" << contFalse << "\t" << contTrue << endl;
        }
      }
    }
    
  } 
}
